// LOCKqz professor extension, in Brightspace (top frame of /d2l/ pages).
// Runs the same LOCKqz Sync the bookmark runs, from the extension's own copy of sync.js, on the
// professor's own Brightspace login. In an ordinary tab it syncs quietly (hidden panel, never a gate); in
// the tab the extension opened for an exam it runs the full panel, which gates the exam.
// On a quiz page it syncs without the 15-minute wait: when the page opens, a few seconds after a Save
// there, and every 2 minutes while the page stays open (an unchanged Brightspace costs LOCKqz no request).
// Also: (1) the one-time "Syncing your classes" card on the professor's first visit after install;
// (2) on the quiz edit / restrictions / special-access pages of an exam LOCKqz protects, the password
// LOCKqz shows one notice (nothing is disabled: special access / extra time must keep working);
// (3) on the quiz pages, exams that carry the professor's own password (LOCKqz leaves those alone): one
// notice with one button, "Protect with LOCKqz".
(() => {
  if (window.top !== window) return;
  const api = globalThis.browser ?? chrome;
  const RED = "#990000";
  const SHIELD = (c, s) => `<svg aria-hidden="true" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M8 11V7a4 4 0 0 1 8 0v4"/><rect x="5" y="11" width="14" height="10" rx="2" fill="${c}"/><circle cx="12" cy="16" r="1.4" fill="#fff" stroke="none"/></svg>`;
  let me = null;   // { key, base, role: "gate" | "tmp" | "browse" }
  // Brightspace's quiz pages (the quiz list, the quiz editor and its settings pages).
  const QUIZ = /\/d2l\/lms\/quizzing\/admin\//i.test(location.pathname) || /\/d2l\/le\/activities\//i.test(location.pathname);
  let busy = 0;   // a sync this page started and has not heard back from (never two at once)
  const inject = (r, force, visible) => {
    const u = new URL(api.runtime.getURL("sync.js"));
    u.searchParams.set("k", r.key); u.searchParams.set("base", r.base); u.searchParams.set("ext", "1");
    if (r.role !== "gate") { u.searchParams.set("nogate", "1"); if (!visible) u.searchParams.set("quiet", "1"); }
    if (force) u.searchParams.set("force", "1");
    // A panel from an earlier sync is still on this page (hidden): re-check through it, never show it.
    else if (r.role === "browse" && document.getElementById("lqz-sync")) u.searchParams.set("auto", "1");
    busy = Date.now();
    u.searchParams.set("v", String(Date.now()));
    const s = document.createElement("script"); s.charset = "utf-8"; s.src = u.href;
    (document.body || document.documentElement).appendChild(s);
  };

  // ---- (1) first visit after install: a bottom-right card, once ----
  let card = null, cardTimer = null;
  const dashUrl = () => ((me && me.base) || "https://professor.lockqz.com") + "/";
  function showCard(bodyHtml, ms) {
    if (!card) {
      card = document.createElement("div"); card.id = "lqz-first";
      card.style.cssText = "position:fixed;right:18px;bottom:18px;z-index:2147483646;width:320px;background:#fff;border-radius:12px;overflow:hidden;" +
        "box-shadow:0 12px 40px rgba(0,0,0,.28);font:14px -apple-system,Segoe UI,Helvetica,Arial,sans-serif;color:#1a1a1a;text-align:left";
      (document.body || document.documentElement).appendChild(card);
    }
    card.innerHTML = `<div style="background:${RED};color:#fff;padding:10px 14px;font-weight:700;font-size:15px;display:flex;align-items:center;gap:8px">${SHIELD("#fff", 18)}LOCKqz<span id="lqz-first-x" style="margin-left:auto;cursor:pointer;font-weight:400;padding:0 2px">&#10005;</span></div><div style="padding:12px 14px;line-height:1.5">${bodyHtml}</div>`;
    const x = card.querySelector("#lqz-first-x"); if (x) x.onclick = hideCard;
    const d = card.querySelector("#lqz-first-dash"); if (d) d.onclick = e => { e.preventDefault(); window.open(dashUrl(), "_blank"); hideCard(); };
    clearTimeout(cardTimer); if (ms) cardTimer = setTimeout(hideCard, ms);
  }
  function hideCard() { clearTimeout(cardTimer); if (card) card.remove(); card = null; }
  let firstWaiting = false;
  const doneCard = n => showCard(`Done${n ? ` \u2014 ${n} class${n === 1 ? "" : "es"} synced` : " \u2014 your classes are synced"}. <a id="lqz-first-dash" href="${dashUrl()}" style="color:${RED};font-weight:700;white-space:nowrap">Open dashboard</a>`, 12000);

  api.runtime.sendMessage({ t: "loaded", quiz: QUIZ }).then(r => {
    if (!r || !r.key) return;
    me = r;
    if (r.first) {
      if (r.run) { firstWaiting = true; showCard("Syncing your classes\u2026 They'll be on your LOCKqz dashboard in about a minute.", 180000); }   // gone by itself if Brightspace never answers (sign-in page)
      else doneCard(0);
    }
    if (r.run) inject(r, !!r.force, r.role === "gate");
  }).catch(() => {});
  // Status from sync.js (it posts to this page when loaded by the extension) -> the extension.
  window.addEventListener("message", e => {
    if (e.source !== window || e.origin !== location.origin) return;
    const d = e.data;
    if (!d || typeof d !== "object" || d.lqzExt !== 1 || typeof d.lqz !== "string") return;
    if (d.lqz === "synced" || d.lqz === "failed") busy = 0;
    if (ownWait && (d.lqz === "synced" || d.lqz === "failed")) ownDone(d);
    if (firstWaiting && (d.lqz === "synced" || d.lqz === "failed")) {
      firstWaiting = false;
      if (d.lqz === "synced" && d.ok === false) { const n = Number(d.errors) || 0;
        showCard(`Synced. ${n} exam${n === 1 ? "" : "s"} could not be updated in Brightspace \u2014 <a href="${dashUrl()}" style="color:${RED};font-weight:700">open the LOCKqz dashboard</a>.`, 12000); }
      else if (d.lqz === "synced") doneCard(Number(d.courses) || 0);
      else showCard(`Could not sync yet: ${String(d.error || "").replace(/[<>]/g, "").slice(0, 140)}`, 12000);
    }
    api.runtime.sendMessage({ t: "from-sync", m: d }).catch(() => {});
  });
  api.runtime.onMessage.addListener(m => {
    if (!m || !me) return;
    if (m.t === "run") inject(me, !!m.force, me.role === "gate");
    if (m.t === "show") {
      const b = document.getElementById("lqz-sync");
      if (b) b.style.display = ""; else inject(me, true, true);
    }
  });

  // ---- quiz pages: an exam saved a moment ago reaches LOCKqz now, not at the next visit ----
  if (QUIZ) {
    const ask = saved => {
      if (!me || me.role !== "browse" || document.hidden || (busy && Date.now() - busy < 90000)) return;
      api.runtime.sendMessage({ t: "quiz", saved }).then(r => { if (r && r.run) inject(me, false, false); }).catch(() => {});
    };
    // Any button on the page whose label starts with Save (Save, Save and Close...), also inside Brightspace's
    // own components. Brightspace needs a moment to store it, so LOCKqz looks twice.
    document.addEventListener("click", e => {
      const hit = (e.composedPath ? e.composedPath() : [e.target]).slice(0, 6).some(n => n && n.nodeType === 1 &&
        /^(BUTTON|D2L-BUTTON|INPUT|A)$/.test(n.tagName) && /^\s*save\b/i.test(String(n.getAttribute("text") || n.value || n.textContent || "").slice(0, 40)));
      if (hit) { setTimeout(() => ask(true), 4000); setTimeout(() => ask(true), 15000); }
    }, true);
    setInterval(() => ask(false), 60000);
  }

  // ---- (2) Brightspace quiz settings of a protected exam: a notice, never a lock ----
  // Nothing on the page is disabled or changed: special access (OSAS extra time) must keep working, and a
  // guessed selector must never grey out the wrong control. One dismissible banner at the top says what
  // LOCKqz manages. (27 Oct 2026: replaces the field lock, which disabled password + special-access controls.)
  const QADMIN = /\/d2l\/lms\/quizzing\/admin\//i.test(location.pathname);
  const qiHere = () => { try { return new URL(location.href).searchParams.get("qi") || ""; } catch { return ""; } };
  function showNotice() {
    if (document.getElementById("lqz-managed")) return;
    const n = document.createElement("div"); n.id = "lqz-managed"; n.setAttribute("role", "note");
    n.style.cssText = `position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:2147483646;max-width:560px;width:calc(100% - 32px);box-sizing:border-box;padding:10px 40px 10px 12px;border:1px solid ${RED};border-radius:10px;background:#fff;box-shadow:0 6px 24px rgba(0,0,0,.18);font:13px/1.4 -apple-system,Segoe UI,Helvetica,Arial,sans-serif;color:#1a1a1a`;
    n.innerHTML = `<span style="display:flex;gap:8px;align-items:flex-start">${SHIELD(RED, 18)}<span><b>LOCKqz protects this exam.</b> Leave its password as it is: LOCKqz sets it and gives it only to students LOCKqz lets in. Special access and extra time work as usual.</span></span>` +
      `<button type="button" aria-label="Close" style="position:absolute;top:6px;right:8px;border:0;background:none;font-size:18px;line-height:1;cursor:pointer;color:#555">&times;</button>`;
    n.querySelector("button").onclick = () => n.remove();
    (document.body || document.documentElement).appendChild(n);
  }
  async function maybeLock() {
    if (!QADMIN) return;
    const qi = qiHere(); if (!qi) return;
    let sched = []; try { sched = (await api.storage.local.get("schedule")).schedule || []; } catch {}
    if (!sched.some(q => q && String(q.qi) === String(qi))) return;   // not a LOCKqz-protected exam
    showNotice();
  }
  maybeLock();

  // ---- (3) exams with the professor's own password: say so, one click to protect ----
  // Which exams: from the last sync (storage "own"). On an exam's own page: that exam. On the quiz list of a
  // class: that class's exams. Nothing on the page is changed; "Not now" is remembered for those exams.
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => "&#" + c.charCodeAt(0) + ";");
  let ownWait = null, ownBox = null, ownShown = "", ownHold = 0;   // ownHold: the result stays on the page this long
  const ouHere = () => { try { return new URL(location.href).searchParams.get("ou") || ""; } catch { return ""; } };
  function ownDraw(html, buttons) {
    if (!ownBox) {
      ownBox = document.createElement("div"); ownBox.id = "lqz-own"; ownBox.setAttribute("role", "note");
      ownBox.style.cssText = `position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:2147483646;max-width:560px;width:calc(100% - 32px);box-sizing:border-box;padding:12px 14px;border:1px solid ${RED};border-radius:10px;background:#fff;box-shadow:0 6px 24px rgba(0,0,0,.18);font:13px/1.45 -apple-system,Segoe UI,Helvetica,Arial,sans-serif;color:#1a1a1a`;
      (document.body || document.documentElement).appendChild(ownBox);
    }
    ownBox.innerHTML = `<span style="display:flex;gap:8px;align-items:flex-start">${SHIELD(RED, 18)}<span>${html}</span></span>` +
      (buttons ? `<span style="display:flex;gap:8px;margin-top:10px;padding-left:26px"><button type="button" id="lqz-own-yes" style="border:0;border-radius:8px;background:${RED};color:#fff;font:inherit;font-weight:700;padding:8px 14px;cursor:pointer">Protect with LOCKqz</button><button type="button" id="lqz-own-no" style="border:1px solid #cfccc4;border-radius:8px;background:#fff;color:#1a1a1a;font:inherit;padding:8px 14px;cursor:pointer">Not now</button></span>` : "");
  }
  const ownHide = () => { if (ownBox) ownBox.remove(); ownBox = null; };
  function ownDone(d) {
    const n = ownWait.length; ownWait = null; ownShown = ""; ownHold = Date.now() + 12000;
    setTimeout(() => { ownHide(); maybeOwn(); }, 12100);
    if (d.lqz === "synced" && d.ok !== false) ownDraw(`<b>Protected.</b> ${n === 1 ? "This exam now opens" : "These exams now open"} only for students with LOCKqz on. Your own password is saved and comes back if you turn LOCKqz off.`, false);
    else ownDraw("LOCKqz took " + (n === 1 ? "this exam" : "these exams") + " on, but Brightspace has not been updated yet. Reload this page in a moment.", false);
  }
  async function maybeOwn() {
    if (!QADMIN || ownWait || Date.now() < ownHold || !me || me.role !== "browse") return;
    let st = {}; try { st = await api.storage.local.get(["own", "ownNo"]); } catch {}
    const no = st.ownNo || {}, qi = qiHere(), ou = ouHere();
    const list = (st.own || []).filter(q => q && !no[q.ou + "-" + q.qi] && (qi ? String(q.qi) === String(qi) : ou && String(q.ou) === String(ou)));
    const sig = list.map(q => q.ou + "-" + q.qi).join(",");
    if (!list.length) { if (ownShown) { ownHide(); ownShown = ""; } return; }
    if (sig === ownShown) return;
    ownShown = sig;
    const names = list.slice(0, 4).map(q => "<b>" + esc(q.name || "Exam") + "</b>").join(", ") + (list.length > 4 ? " and " + (list.length - 4) + " more" : "");
    ownDraw(list.length === 1 ? `${names} has its own password, so LOCKqz is not protecting it.` : `${list.length} exams have their own password, so LOCKqz is not protecting them: ${names}.`, true);
    ownBox.querySelector("#lqz-own-no").onclick = () => { api.runtime.sendMessage({ t: "own-no", items: list }).catch(() => {}); ownHide(); };
    ownBox.querySelector("#lqz-own-yes").onclick = async () => {
      ownDraw("Protecting\u2026", false);
      let r = null; try { r = await api.runtime.sendMessage({ t: "protect", items: list }); } catch {}
      if (!r || !r.ok) { ownShown = ""; ownDraw(esc((r && r.error) || "LOCKqz could not do that just now. Try again in a moment."), false); setTimeout(() => { ownHide(); maybeOwn(); }, 8000); return; }
      ownWait = list; inject(me, true, false);   // a full sync now: saves the professor's password, sets LOCKqz's
      setTimeout(() => { if (ownWait) ownDone({ lqz: "failed" }); }, 60000);
    };
  }
  // After this page's own sync has told the extension what it found, and whenever that changes.
  if (QADMIN) { try { api.storage.onChanged.addListener((ch, area) => { if (area === "local" && (ch.own || ch.ownNo)) maybeOwn(); }); } catch {} setTimeout(maybeOwn, 1500); }
})();
